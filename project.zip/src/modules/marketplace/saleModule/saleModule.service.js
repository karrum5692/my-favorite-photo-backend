import prisma from '../../../config/db.js';

//나의 포토카드 가져오기
async function getMySale(ownerId) {
  return await prisma.photoCard.findMany({
    where: { ownerId: ownerId, status: 'OWNED' },
    select: {
      id: true,
      owner: { select: { nickname: true } },
      quantity: true,
      template: {
        select: {
          title: true,
          imageUrl: true,
          grade: true,
          genre: true,
          price: true,
        },
      },
    },
  });
}

//포토카드 판매하기 생성
async function createSale(ownerId, photoCardId, data) {
  return await prisma.$transaction(async (tx) => {
    const card = await tx.photoCard.findUnique({
      where: { id: photoCardId },
    });

    if (!card) {
      throw new Error('카드가 존재하지 않습니다.');
    }

    if (card.ownerId !== ownerId) {
      throw new Error('본인의 카드가 아닙니다.');
    }

    // 판매글이 존재하는지 -> 동일 카드가 selling 중인지 확인
    const existedList = await tx.saleListing.findFirst({
      where: { photoCardId: photoCardId, status: 'SELLING' },
    });

    if (existedList) {
      throw new Error(
        '이미 판매 중인 카드입니다. 판매글을 확인하시길 바랍니다.'
      );
    }

    // 보유 수량 범위 내에서 판매수량을 선택해야함
    if (data.quantity > card.quantity) {
      throw new Error('판매 수량은 보유 수량을 초과할 수 없습니다.');
    }

    const changedStatus = await tx.photoCard.updateMany({
      where: {
        id: photoCardId,
        status: 'OWNED',
      },
      data: {
        status: 'ON_SALE',
      },
    });

    if (changedStatus.count === 0) {
      throw new Error('이미 판매 중이거나 상태가 변경되었습니다.');
    }

    const sale = await tx.saleListing.create({
      data: {
        seller: { connect: { id: ownerId } },
        remainQuantity: data.quantity,
        photoCard: { connect: { id: photoCardId } },
        quantity: data.quantity,
        price: data.price,
        exchangeGrade: data.exchangeGrade,
        exchangeGenre: data.exchangeGenre,
        exchangeDescription: data.exchangeDescription,
      },
    });

    return sale;
  });
}

export default { getMySale, createSale };
