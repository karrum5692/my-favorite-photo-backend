import pointService from './point.service.js';

const getPoint = async function (req, res, next) {
  try {
    const id = req.auth.userId;
    const point = await pointService.getPoint(id);
    res.status(200).json(point);
  } catch (error) {
    next(error);
  }
};

const getPointHistory = async function (req, res, next) {
  try {
    const id = req.auth.userId;
    const pointHistory = await pointService.getPointHistory(id);
    res.status(200).json(pointHistory);
  } catch (error) {
    next(error);
  }
};

const randomPoint = async function (req, res, next) {
  try {
    const id = req.auth.userId;
    const resultPoint = await pointService.randomPoint(id);
    res.status(201).json(resultPoint);
  } catch (error) {
    next(error);
  }
};

export default { getPoint, getPointHistory, randomPoint };
