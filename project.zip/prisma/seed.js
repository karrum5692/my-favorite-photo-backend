import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcrypt';

const prisma = new PrismaClient();

// =====================
// ENUM 매핑 사전 (Prisma Enum 값 규격 일치)
// =====================
const genreMap = {
  앨범: 'ALBUM',
  특전: 'SPECIAL',
  팬싸: 'FAN_SIGN',
  시즌그리팅: 'SEASON_GREETING',
  팬미팅: 'FAN_MEETING',
  콘서트: 'CONCERT',
  MD: 'MD',
  콜라보: 'COLLABORATION',
  팬클럽: 'FAN_CLUB',
  기타: 'OTHER',
};

const gradeMap = {
  common: 'COMMON',
  rare: 'RARE',
  'super rare': 'SUPER_RARE',
  legendary: 'LEGENDARY',
};

// =====================
// 원본 데이터 주입
// =====================
const RAW_USERS = [
  {
    id: 1,
    nickname: 'user1',
    email: 'user1@example.com',
    password: 'password1',
    points: 16000,
  },
  {
    id: 2,
    nickname: 'user2',
    email: 'user2@example.com',
    password: 'password2',
    points: 17000,
  },
  {
    id: 3,
    nickname: 'user3',
    email: 'user3@example.com',
    password: 'password3',
    points: 24000,
  },
  {
    id: 4,
    nickname: 'user4',
    email: 'user4@example.com',
    password: 'password4',
    points: 19000,
  },
  {
    id: 5,
    nickname: 'user5',
    email: 'user5@example.com',
    password: 'password5',
    points: 25000,
  },
  {
    id: 6,
    nickname: 'user6',
    email: 'user6@example.com',
    password: 'password6',
    points: 20000,
  },
  {
    id: 7,
    nickname: 'user7',
    email: 'user7@example.com',
    password: 'password7',
    points: 14000,
  },
  {
    id: 8,
    nickname: 'user8',
    email: 'user8@example.com',
    password: 'password8',
    points: 5000,
  },
  {
    id: 9,
    nickname: 'user9',
    email: 'user9@example.com',
    password: 'password9',
    points: 12000,
  },
  {
    id: 10,
    nickname: 'user10',
    email: 'user10@example.com',
    password: 'password10',
    points: 27000,
  },
  {
    id: 11,
    nickname: 'user11',
    email: 'user11@example.com',
    password: 'password11',
    points: 2000,
  },
  {
    id: 12,
    nickname: 'user12',
    email: 'user12@example.com',
    password: 'password12',
    points: 2000,
  },
  {
    id: 13,
    nickname: 'user13',
    email: 'user13@example.com',
    password: 'password13',
    points: 15000,
  },
  {
    id: 14,
    nickname: 'user14',
    email: 'user14@example.com',
    password: 'password14',
    points: 2000,
  },
  {
    id: 15,
    nickname: 'user15',
    email: 'user15@example.com',
    password: 'password15',
    points: 11000,
  },
  {
    id: 16,
    nickname: 'user16',
    email: 'user16@example.com',
    password: 'password16',
    points: 18000,
  },
  {
    id: 17,
    nickname: 'user17',
    email: 'user17@example.com',
    password: 'password17',
    points: 1000,
  },
  {
    id: 18,
    nickname: 'user18',
    email: 'user18@example.com',
    password: 'password18',
    points: 2000,
  },
  {
    id: 19,
    nickname: 'user19',
    email: 'user19@example.com',
    password: 'password19',
    points: 19000,
  },
  {
    id: 20,
    nickname: 'user20',
    email: 'user20@example.com',
    password: 'password20',
    points: 7000,
  },
];

const RAW_TEMPLATES = [
  {
    id: 1,
    userId: 2,
    name: '빌리 문수아 콘서트',
    description: '빌리 문수아 콘서트 포카입니다.',
    genre: '콘서트',
    grade: 'common',
    price: 8000,
    totalQuantity: 3,
    imageUrl: 'https://picsum.photos/360/270?random=10',
  },
  {
    id: 2,
    userId: 11,
    name: 'NCT 유우시 특전',
    description: 'NCT 유우시 특전 포카입니다.',
    genre: '특전',
    grade: 'super rare',
    price: 22000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=11',
  },
  {
    id: 3,
    userId: 14,
    name: 'NCT 시온 앨범',
    description: 'NCT 시온 앨범 포카입니다.',
    genre: '앨범',
    grade: 'rare',
    price: 12000,
    totalQuantity: 3,
    imageUrl: 'https://picsum.photos/360/270?random=13',
  },
  {
    id: 4,
    userId: 4,
    name: '소녀시대 유리 콜라보',
    description: '소녀시대 유리 콜라보 포카입니다.',
    genre: '콜라보',
    grade: 'common',
    price: 10000,
    totalQuantity: 2,
    imageUrl: 'https://picsum.photos/360/270?random=15',
  },
  {
    id: 5,
    userId: 20,
    name: 'IVE 레이 콜라보',
    description: 'IVE 레이 콜라보 포카입니다.',
    genre: '콜라보',
    grade: 'super rare',
    price: 26000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=8',
  },
  {
    id: 6,
    userId: 7,
    name: '소녀시대 태연 MD',
    description: '소녀시대 태연 MD 포카입니다.',
    genre: 'MD',
    grade: 'common',
    price: 27000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=14',
  },
  {
    id: 7,
    userId: 15,
    name: 'DKZ 재찬 팬싸',
    description: 'DKZ 재찬 팬싸 포카입니다.',
    genre: '팬싸',
    grade: 'super rare',
    price: 12000,
    totalQuantity: 2,
    imageUrl: 'https://picsum.photos/360/270?random=5',
  },
  {
    id: 8,
    userId: 20,
    name: 'DAY6 도운 콘서트',
    description: 'DAY6 도운 콘서트 포카입니다.',
    genre: '콘서트',
    grade: 'common',
    price: 17000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=1',
  },
  {
    id: 9,
    userId: 13,
    name: '트와이스 채영 팬싸',
    description: '트와이스 채영 팬싸 포카입니다.',
    genre: '팬싸',
    grade: 'legendary',
    price: 8000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=18',
  },
  {
    id: 10,
    userId: 14,
    name: '이달의 소녀 현진 기타',
    description: '이달의 소녀 현진 기타 포카입니다.',
    genre: '기타',
    grade: 'legendary',
    price: 21000,
    totalQuantity: 2,
    imageUrl: 'https://picsum.photos/360/270?random=2',
  },
  {
    id: 11,
    userId: 10,
    name: '우주소녀 은서 콘서트',
    description: '우주소녀 은서 콘서트 포카입니다.',
    genre: '콘서트',
    grade: 'common',
    price: 29000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=14',
  },
  {
    id: 12,
    userId: 2,
    name: '세븐틴 준 팬싸',
    description: '세븐틴 준 팬싸 포카입니다.',
    genre: '팬싸',
    grade: 'common',
    price: 17000,
    totalQuantity: 2,
    imageUrl: 'https://picsum.photos/360/270?random=16',
  },
  {
    id: 13,
    userId: 13,
    name: 'DKZ 재찬 앨범',
    description: 'DKZ 재찬 앨범 포카입니다.',
    genre: '앨범',
    grade: 'rare',
    price: 8000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=7',
  },
  {
    id: 14,
    userId: 3,
    name: '베리베리 호영 콘서트',
    description: '베리베리 호영 콘서트 포카입니다.',
    genre: '콘서트',
    grade: 'rare',
    price: 9000,
    totalQuantity: 2,
    imageUrl: 'https://picsum.photos/360/270?random=13',
  },
  {
    id: 15,
    userId: 9,
    name: '세븐틴 조슈아 콘서트',
    description: '세븐틴 조슈아 콘서트 포카입니다.',
    genre: '콘서트',
    grade: 'common',
    price: 21000,
    totalQuantity: 2,
    imageUrl: 'https://picsum.photos/360/270?random=2',
  },
  {
    id: 16,
    userId: 3,
    name: '여자아이들 민니 팬싸',
    description: '여자아이들 민니 팬싸 포카입니다.',
    genre: '팬싸',
    grade: 'super rare',
    price: 28000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=8',
  },
  {
    id: 17,
    userId: 10,
    name: 'TXT 휴닝카이 특전',
    description: 'TXT 휴닝카이 특전 포카입니다.',
    genre: '특전',
    grade: 'common',
    price: 25000,
    totalQuantity: 3,
    imageUrl: 'https://picsum.photos/360/270?random=19',
  },
  {
    id: 18,
    userId: 1,
    name: '여자아이들 우기 콘서트',
    description: '여자아이들 우기 콘서트 포카입니다.',
    genre: '콘서트',
    grade: 'common',
    price: 18000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=3',
  },
  {
    id: 19,
    userId: 5,
    name: '세븐틴 민규 팬싸',
    description: '세븐틴 민규 팬싸 포카입니다.',
    genre: '팬싸',
    grade: 'legendary',
    price: 19000,
    totalQuantity: 2,
    imageUrl: 'https://picsum.photos/360/270?random=6',
  },
  {
    id: 20,
    userId: 10,
    name: 'NCT 정우 팬미팅',
    description: 'NCT 정우 팬미팅 포카입니다.',
    genre: '팬미팅',
    grade: 'rare',
    price: 8000,
    totalQuantity: 3,
    imageUrl: 'https://picsum.photos/360/270?random=5',
  },
  {
    id: 21,
    userId: 3,
    name: '스테이씨 수민 특전',
    description: '스테이씨 수민 특전 포카입니다.',
    genre: '특전',
    grade: 'common',
    price: 24000,
    totalQuantity: 3,
    imageUrl: 'https://picsum.photos/360/270?random=6',
  },
  {
    id: 22,
    userId: 12,
    name: 'CIX BX MD',
    description: 'CIX BX MD 포카입니다.',
    genre: 'MD',
    grade: 'legendary',
    price: 18000,
    totalQuantity: 2,
    imageUrl: 'https://picsum.photos/360/270?random=11',
  },
  {
    id: 23,
    userId: 15,
    name: 'NCT 쟈니 시즌그리팅',
    description: 'NCT 쟈니 시즌그리팅 포카입니다.',
    genre: '시즌그리팅',
    grade: 'super rare',
    price: 20000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=7',
  },
  {
    id: 24,
    userId: 13,
    name: 'IVE 가을 앨범',
    description: 'IVE 가을 앨범 포카입니다.',
    genre: '앨범',
    grade: 'rare',
    price: 21000,
    totalQuantity: 2,
    imageUrl: 'https://picsum.photos/360/270?random=1',
  },
  {
    id: 25,
    userId: 3,
    name: 'EVNNE 박지후 MD',
    description: 'EVNNE 박지후 MD 포카입니다.',
    genre: 'MD',
    grade: 'super rare',
    price: 11000,
    totalQuantity: 2,
    imageUrl: 'https://picsum.photos/360/270?random=3',
  },
  {
    id: 26,
    userId: 11,
    name: '세븐틴 민규 특전',
    description: '세븐틴 민규 특전 포카입니다.',
    genre: '특전',
    grade: 'rare',
    price: 20000,
    totalQuantity: 2,
    imageUrl: 'https://picsum.photos/360/270?random=11',
  },
  {
    id: 27,
    userId: 14,
    name: '소녀시대 써니 MD',
    description: '소녀시대 써니 MD 포카입니다.',
    genre: 'MD',
    grade: 'legendary',
    price: 20000,
    totalQuantity: 3,
    imageUrl: 'https://picsum.photos/360/270?random=18',
  },
  {
    id: 28,
    userId: 7,
    name: 'EXO 시우민 콜라보',
    description: 'EXO 시우민 콜라보 포카입니다.',
    genre: '콜라보',
    grade: 'rare',
    price: 20000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=0',
  },
  {
    id: 29,
    userId: 2,
    name: 'NCT 쟈니 팬미팅',
    description: 'NCT 쟈니 팬미팅 포카입니다.',
    genre: '팬미팅',
    grade: 'legendary',
    price: 28000,
    totalQuantity: 3,
    imageUrl: 'https://picsum.photos/360/270?random=15',
  },
  {
    id: 30,
    userId: 18,
    name: '에이티즈 산 앨범',
    description: '에이티즈 산 앨범 포카입니다.',
    genre: '앨범',
    grade: 'super rare',
    price: 15000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=9',
  },
  {
    id: 31,
    userId: 17,
    name: '펜타곤 우석 콘서트',
    description: '펜타곤 우석 콘서트 포카입니다.',
    genre: '콘서트',
    grade: 'legendary',
    price: 12000,
    totalQuantity: 2,
    imageUrl: 'https://picsum.photos/360/270?random=5',
  },
  {
    id: 32,
    userId: 3,
    name: '에스파 지젤 MD',
    description: '에스파 지젤 MD 포카입니다.',
    genre: 'MD',
    grade: 'rare',
    price: 11000,
    totalQuantity: 3,
    imageUrl: 'https://picsum.photos/360/270?random=10',
  },
  {
    id: 33,
    userId: 13,
    name: '세븐틴 에스쿱스 특전',
    description: '세븐틴 에스쿱스 특전 포카입니다.',
    genre: '특전',
    grade: 'legendary',
    price: 27000,
    totalQuantity: 3,
    imageUrl: 'https://picsum.photos/360/270?random=9',
  },
  {
    id: 34,
    userId: 1,
    name: 'CLASS:y 박보은 MD',
    description: 'CLASS:y 박보은 MD 포카입니다.',
    genre: 'MD',
    grade: 'common',
    price: 26000,
    totalQuantity: 3,
    imageUrl: 'https://picsum.photos/360/270?random=18',
  },
  {
    id: 35,
    userId: 11,
    name: 'SF9 로운 팬싸',
    description: 'SF9 로운 팬싸 포카입니다.',
    genre: '팬싸',
    grade: 'common',
    price: 12000,
    totalQuantity: 2,
    imageUrl: 'https://picsum.photos/360/270?random=13',
  },
  {
    id: 36,
    userId: 19,
    name: '이달의 소녀 진솔 팬싸',
    description: '이달의 소녀 진솔 팬싸 포카입니다.',
    genre: '팬싸',
    grade: 'legendary',
    price: 18000,
    totalQuantity: 2,
    imageUrl: 'https://picsum.photos/360/270?random=15',
  },
  {
    id: 37,
    userId: 6,
    name: '르세라핌 허윤진 앨범',
    description: '르세라핌 허윤진 앨범 포카입니다.',
    genre: '앨범',
    grade: 'rare',
    price: 22000,
    totalQuantity: 3,
    imageUrl: 'https://picsum.photos/360/270?random=8',
  },
  {
    id: 38,
    userId: 1,
    name: '크래비티 태영 MD',
    description: '크래비티 태영 MD 포카입니다.',
    genre: 'MD',
    grade: 'rare',
    price: 7000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=8',
  },
  {
    id: 39,
    userId: 20,
    name: 'EXO 첸 앨범',
    description: 'EXO 첸 앨범 포카입니다.',
    genre: '앨범',
    grade: 'rare',
    price: 9000,
    totalQuantity: 3,
    imageUrl: 'https://picsum.photos/360/270?random=5',
  },
  {
    id: 40,
    userId: 7,
    name: 'CLASS:y 박보은 팬미팅',
    description: 'CLASS:y 박보은 팬미팅 포카입니다.',
    genre: '팬미팅',
    grade: 'rare',
    price: 18000,
    totalQuantity: 2,
    imageUrl: 'https://picsum.photos/360/270?random=16',
  },
  {
    id: 41,
    userId: 12,
    name: '에이티즈 우영 팬클럽',
    description: '에이티즈 우영 팬클럽 포카입니다.',
    genre: '팬클럽',
    grade: 'legendary',
    price: 11000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=8',
  },
  {
    id: 42,
    userId: 15,
    name: 'NCT 시온 팬클럽',
    description: 'NCT 시온 팬클럽 포카입니다.',
    genre: '팬클럽',
    grade: 'common',
    price: 23000,
    totalQuantity: 2,
    imageUrl: 'https://picsum.photos/360/270?random=7',
  },
  {
    id: 43,
    userId: 13,
    name: 'NCT 리쿠 MD',
    description: 'NCT 리쿠 MD 포카입니다.',
    genre: 'MD',
    grade: 'legendary',
    price: 27000,
    totalQuantity: 2,
    imageUrl: 'https://picsum.photos/360/270?random=1',
  },
  {
    id: 44,
    userId: 2,
    name: 'NMIXX 규진 콘서트',
    description: 'NMIXX 규진 콘서트 포카입니다.',
    genre: '콘서트',
    grade: 'super rare',
    price: 19000,
    totalQuantity: 2,
    imageUrl: 'https://picsum.photos/360/270?random=9',
  },
  {
    id: 45,
    userId: 13,
    name: '블랙핑크 지수 기타',
    description: '블랙핑크 지수 기타 포카입니다.',
    genre: '기타',
    grade: 'common',
    price: 22000,
    totalQuantity: 3,
    imageUrl: 'https://picsum.photos/360/270?random=5',
  },
  {
    id: 46,
    userId: 6,
    name: 'ZEROBASEONE 박건욱 MD',
    description: 'ZEROBASEONE 박건욱 MD 포카입니다.',
    genre: 'MD',
    grade: 'common',
    price: 27000,
    totalQuantity: 2,
    imageUrl: 'https://picsum.photos/360/270?random=7',
  },
  {
    id: 47,
    userId: 18,
    name: '세븐틴 민규 MD',
    description: '세븐틴 민규 MD 포카입니다.',
    genre: 'MD',
    grade: 'common',
    price: 23000,
    totalQuantity: 2,
    imageUrl: 'https://picsum.photos/360/270?random=7',
  },
  {
    id: 48,
    userId: 5,
    name: '이달의 소녀 최리 팬클럽',
    description: '이달의 소녀 최리 팬클럽 포카입니다.',
    genre: '팬클럽',
    grade: 'legendary',
    price: 13000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=16',
  },
  {
    id: 49,
    userId: 9,
    name: '이달의 소녀 이브 앨범',
    description: '이달의 소녀 이브 앨범 포카입니다.',
    genre: '앨범',
    grade: 'legendary',
    price: 17000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=15',
  },
  {
    id: 50,
    userId: 17,
    name: '엔하이픈 정원 MD',
    description: '엔하이픈 정원 MD 포카입니다.',
    genre: 'MD',
    grade: 'super rare',
    price: 15000,
    totalQuantity: 2,
    imageUrl: 'https://picsum.photos/360/270?random=2',
  },
  {
    id: 51,
    userId: 10,
    name: '에스파 카리나 특전',
    description: '에스파 카리나 특전 포카입니다.',
    genre: '특전',
    grade: 'rare',
    price: 7000,
    totalQuantity: 3,
    imageUrl: 'https://picsum.photos/360/270?random=9',
  },
  {
    id: 52,
    userId: 9,
    name: '오마이걸 승희 앨범',
    description: '오마이걸 승희 앨범 포카입니다.',
    genre: '앨범',
    grade: 'legendary',
    price: 18000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=13',
  },
  {
    id: 53,
    userId: 8,
    name: 'NCT 유타 시즌그리팅',
    description: 'NCT 유타 시즌그리팅 포카입니다.',
    genre: '시즌그리팅',
    grade: 'legendary',
    price: 18000,
    totalQuantity: 2,
    imageUrl: 'https://picsum.photos/360/270?random=18',
  },
  {
    id: 54,
    userId: 15,
    name: '온앤오프 효진 콘서트',
    description: '온앤오프 효진 콘서트 포카입니다.',
    genre: '콘서트',
    grade: 'legendary',
    price: 7000,
    totalQuantity: 3,
    imageUrl: 'https://picsum.photos/360/270?random=3',
  },
  {
    id: 55,
    userId: 17,
    name: 'NCT 샤오쥔 앨범',
    description: 'NCT 샤오쥔 앨범 포카입니다.',
    genre: '앨범',
    grade: 'rare',
    price: 10000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=19',
  },
  {
    id: 56,
    userId: 16,
    name: 'NMIXX 지우 앨범',
    description: 'NMIXX 지우 앨범 포카입니다.',
    genre: '앨범',
    grade: 'common',
    price: 23000,
    totalQuantity: 2,
    imageUrl: 'https://picsum.photos/360/270?random=0',
  },
  {
    id: 57,
    userId: 8,
    name: '더보이즈 주연 팬클럽',
    description: '더보이즈 주연 팬클럽 포카입니다.',
    genre: '팬클럽',
    grade: 'legendary',
    price: 12000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=1',
  },
  {
    id: 58,
    userId: 2,
    name: '트와이스 모모 팬미팅',
    description: '트와이스 모모 팬미팅 포카입니다.',
    genre: '팬미팅',
    grade: 'legendary',
    price: 28000,
    totalQuantity: 3,
    imageUrl: 'https://picsum.photos/360/270?random=13',
  },
  {
    id: 59,
    userId: 20,
    name: '아스트로 진진 특전',
    description: '아스트로 진진 특전 포카입니다.',
    genre: '특전',
    grade: 'common',
    price: 11000,
    totalQuantity: 2,
    imageUrl: 'https://picsum.photos/360/270?random=3',
  },
  {
    id: 60,
    userId: 8,
    name: '트레저 마시호 앨범',
    description: '트레저 마시호 앨범 포카입니다.',
    genre: '앨범',
    grade: 'rare',
    price: 17000,
    totalQuantity: 3,
    imageUrl: 'https://picsum.photos/360/270?random=0',
  },
  {
    id: 61,
    userId: 15,
    name: '블랙핑크 리사 팬클럽',
    description: '블랙핑크 리사 팬클럽 포카입니다.',
    genre: '팬클럽',
    grade: 'legendary',
    price: 28000,
    totalQuantity: 3,
    imageUrl: 'https://picsum.photos/360/270?random=9',
  },
  {
    id: 62,
    userId: 2,
    name: 'EVNNE 유승언 팬싸',
    description: 'EVNNE 유승언 팬싸 포카입니다.',
    genre: '팬싸',
    grade: 'super rare',
    price: 25000,
    totalQuantity: 3,
    imageUrl: 'https://picsum.photos/360/270?random=11',
  },
  {
    id: 63,
    userId: 6,
    name: '아스트로 문빈 기타',
    description: '아스트로 문빈 기타 포카입니다.',
    genre: '기타',
    grade: 'rare',
    price: 29000,
    totalQuantity: 3,
    imageUrl: 'https://picsum.photos/360/270?random=19',
  },
  {
    id: 64,
    userId: 1,
    name: '세븐틴 우지 앨범',
    description: '세븐틴 우지 앨범 포카입니다.',
    genre: '앨범',
    grade: 'legendary',
    price: 13000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=12',
  },
  {
    id: 65,
    userId: 7,
    name: '트레저 지훈 팬싸',
    description: '트레저 지훈 팬싸 포카입니다.',
    genre: '팬싸',
    grade: 'super rare',
    price: 15000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=18',
  },
  {
    id: 66,
    userId: 15,
    name: 'NCT 유타 콜라보',
    description: 'NCT 유타 콜라보 포카입니다.',
    genre: '콜라보',
    grade: 'super rare',
    price: 13000,
    totalQuantity: 2,
    imageUrl: 'https://picsum.photos/360/270?random=2',
  },
  {
    id: 67,
    userId: 7,
    name: '베리베리 연호 MD',
    description: '베리베리 연호 MD 포카입니다.',
    genre: 'MD',
    grade: 'legendary',
    price: 20000,
    totalQuantity: 2,
    imageUrl: 'https://picsum.photos/360/270?random=2',
  },
  {
    id: 68,
    userId: 4,
    name: 'EVNNE 케이타 콘서트',
    description: 'EVNNE 케이타 콘서트 포카입니다.',
    genre: '콘서트',
    grade: 'super rare',
    price: 13000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=7',
  },
  {
    id: 69,
    userId: 11,
    name: 'EVNNE 이정현 특전',
    description: 'EVNNE 이정현 특전 포카입니다.',
    genre: '특전',
    grade: 'rare',
    price: 9000,
    totalQuantity: 3,
    imageUrl: 'https://picsum.photos/360/270?random=9',
  },
  {
    id: 70,
    userId: 7,
    name: 'CLASS:y 명형서 팬싸',
    description: 'CLASS:y 명형서 팬싸 포카입니다.',
    genre: '팬싸',
    grade: 'super rare',
    price: 20000,
    totalQuantity: 2,
    imageUrl: 'https://picsum.photos/360/270?random=17',
  },
  {
    id: 71,
    userId: 9,
    name: '슈퍼엠 텐 기타',
    description: '슈퍼엠 텐 기타 포카입니다.',
    genre: '기타',
    grade: 'super rare',
    price: 15000,
    totalQuantity: 3,
    imageUrl: 'https://picsum.photos/360/270?random=13',
  },
  {
    id: 72,
    userId: 7,
    name: '빌리 츠키 팬미팅',
    description: '빌리 츠키 팬미팅 포카입니다.',
    genre: '팬미팅',
    grade: 'common',
    price: 25000,
    totalQuantity: 2,
    imageUrl: 'https://picsum.photos/360/270?random=11',
  },
  {
    id: 73,
    userId: 5,
    name: '세븐틴 조슈아 앨범',
    description: '세븐틴 조슈아 앨범 포카입니다.',
    genre: '앨범',
    grade: 'super rare',
    price: 13000,
    totalQuantity: 2,
    imageUrl: 'https://picsum.photos/360/270?random=19',
  },
  {
    id: 74,
    userId: 9,
    name: '르세라핌 카즈하 콜라보',
    description: '르세라핌 카즈하 콜라보 포카입니다.',
    genre: '콜라보',
    grade: 'super rare',
    price: 12000,
    totalQuantity: 2,
    imageUrl: 'https://picsum.photos/360/270?random=14',
  },
  {
    id: 75,
    userId: 16,
    name: 'TXT 범규 팬미팅',
    description: 'TXT 범규 팬미팅 포카입니다.',
    genre: '팬미팅',
    grade: 'legendary',
    price: 28000,
    totalQuantity: 2,
    imageUrl: 'https://picsum.photos/360/270?random=4',
  },
  {
    id: 76,
    userId: 16,
    name: '르세라핌 사쿠라 앨범',
    description: '르세라핌 사쿠라 앨범 포카입니다.',
    genre: '앨범',
    grade: 'legendary',
    price: 20000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=11',
  },
  {
    id: 77,
    userId: 4,
    name: 'SF9 휘영 특전',
    description: 'SF9 휘영 특전 포카입니다.',
    genre: '특전',
    grade: 'legendary',
    price: 15000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=14',
  },
  {
    id: 78,
    userId: 13,
    name: 'ITZY 유나 기타',
    description: 'ITZY 유나 기타 포카입니다.',
    genre: '기타',
    grade: 'rare',
    price: 29000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=6',
  },
  {
    id: 79,
    userId: 5,
    name: '아스트로 차은우 팬싸',
    description: '아스트로 차은우 팬싸 포카입니다.',
    genre: '팬싸',
    grade: 'legendary',
    price: 12000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=1',
  },
  {
    id: 80,
    userId: 13,
    name: 'NCT 도영 팬싸',
    description: 'NCT 도영 팬싸 포카입니다.',
    genre: '팬싸',
    grade: 'rare',
    price: 25000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=4',
  },
  {
    id: 81,
    userId: 18,
    name: '펜타곤 우석 콘서트',
    description: '펜타곤 우석 콘서트 포카입니다.',
    genre: '콘서트',
    grade: 'super rare',
    price: 22000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=10',
  },
  {
    id: 82,
    userId: 2,
    name: 'NCT 헨드리 특전',
    description: 'NCT 헨드리 특전 포카입니다.',
    genre: '특전',
    grade: 'rare',
    price: 14000,
    totalQuantity: 3,
    imageUrl: 'https://picsum.photos/360/270?random=12',
  },
  {
    id: 83,
    userId: 8,
    name: 'SF9 영빈 특전',
    description: 'SF9 영빈 특전 포카입니다.',
    genre: '특전',
    grade: 'super rare',
    price: 25000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=13',
  },
  {
    id: 84,
    userId: 6,
    name: '케플러 최유진 기타',
    description: '케플러 최유진 기타 포카입니다.',
    genre: '기타',
    grade: 'rare',
    price: 10000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=2',
  },
  {
    id: 85,
    userId: 2,
    name: '에이티즈 홍중 팬미팅',
    description: '에이티즈 홍중 팬미팅 포카입니다.',
    genre: '팬미팅',
    grade: 'super rare',
    price: 17000,
    totalQuantity: 3,
    imageUrl: 'https://picsum.photos/360/270?random=3',
  },
  {
    id: 86,
    userId: 4,
    name: 'SF9 영빈 콜라보',
    description: 'SF9 영빈 콜라보 포카입니다.',
    genre: '콜라보',
    grade: 'rare',
    price: 21000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=5',
  },
  {
    id: 87,
    userId: 9,
    name: '아스트로 윤산하 팬미팅',
    description: '아스트로 윤산하 팬미팅 포카입니다.',
    genre: '팬미팅',
    grade: 'common',
    price: 25000,
    totalQuantity: 2,
    imageUrl: 'https://picsum.photos/360/270?random=8',
  },
  {
    id: 88,
    userId: 17,
    name: 'NCT 해찬 팬싸',
    description: 'NCT 해찬 팬싸 포카입니다.',
    genre: '팬싸',
    grade: 'super rare',
    price: 17000,
    totalQuantity: 3,
    imageUrl: 'https://picsum.photos/360/270?random=0',
  },
  {
    id: 89,
    userId: 20,
    name: 'CIX 용희 시즌그리팅',
    description: 'CIX 용희 시즌그리팅 포카입니다.',
    genre: '시즌그리팅',
    grade: 'rare',
    price: 28000,
    totalQuantity: 3,
    imageUrl: 'https://picsum.photos/360/270?random=8',
  },
  {
    id: 90,
    userId: 20,
    name: '소녀시대 효연 기타',
    description: '소녀시대 효연 기타 포카입니다.',
    genre: '기타',
    grade: 'common',
    price: 23000,
    totalQuantity: 2,
    imageUrl: 'https://picsum.photos/360/270?random=18',
  },
  {
    id: 91,
    userId: 4,
    name: '스테이씨 세은 콜라보',
    description: '스테이씨 세은 콜라보 포카입니다.',
    genre: '콜라보',
    grade: 'legendary',
    price: 10000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=14',
  },
  {
    id: 92,
    userId: 15,
    name: '펜타곤 신원 콘서트',
    description: '펜타곤 신원 콘서트 포카입니다.',
    genre: '콘서트',
    grade: 'legendary',
    price: 29000,
    totalQuantity: 3,
    imageUrl: 'https://picsum.photos/360/270?random=9',
  },
  {
    id: 93,
    userId: 8,
    name: '실버틴 승관 앨범',
    description: '세븐틴 승관 앨범 포카입니다.',
    genre: '앨범',
    grade: 'legendary',
    price: 11000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=8',
  },
  {
    id: 94,
    userId: 18,
    name: 'EXO 카이 MD',
    description: 'EXO 카이 MD 포카입니다.',
    genre: 'MD',
    grade: 'super rare',
    price: 19000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=3',
  },
  {
    id: 95,
    userId: 9,
    name: '베리베리 호영 팬싸',
    description: '베리베리 호영 팬싸 포카입니다.',
    genre: '팬싸',
    grade: 'rare',
    price: 23000,
    totalQuantity: 3,
    imageUrl: 'https://picsum.photos/360/270?random=17',
  },
  {
    id: 96,
    userId: 10,
    name: 'NMIXX 지우 콜라보',
    description: 'NMIXX 지우 콜라보 포카입니다.',
    genre: '콜라보',
    grade: 'rare',
    price: 25000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=16',
  },
  {
    id: 97,
    userId: 12,
    name: '펜타곤 키노 콘서트',
    description: '펜타곤 키노 콘서트 포카입니다.',
    genre: '콘서트',
    grade: 'rare',
    price: 29000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=16',
  },
  {
    id: 98,
    userId: 15,
    name: '에이티즈 성화 팬미팅',
    description: '에이티즈 성화 팬미팅 포카입니다.',
    genre: '팬미팅',
    grade: 'legendary',
    price: 26000,
    totalQuantity: 3,
    imageUrl: 'https://picsum.photos/360/270?random=11',
  },
  {
    id: 99,
    userId: 7,
    name: '이달의 소녀 현진 시즌그리팅',
    description: '이달의 소녀 현진 시즌그리팅 포카입니다.',
    genre: '시즌그리팅',
    grade: 'super rare',
    price: 26000,
    totalQuantity: 3,
    imageUrl: 'https://picsum.photos/360/270?random=14',
  },
  {
    id: 100,
    userId: 14,
    name: 'NCT 사쿠야 기타',
    description: 'NCT 사쿠야 기타 포카입니다.',
    genre: '기타',
    grade: 'rare',
    price: 10000,
    totalQuantity: 1,
    imageUrl: 'https://picsum.photos/360/270?random=17',
  },
];

async function main() {
  console.log('🌱 Seeding started (JavaScript Version - Prisma 6 Sync)...');

  // 데이터 무결성을 위해 기존 데이터를 역순으로 싹 날려줍니다. (선택사항, 필요 없으면 주석 처리)
  console.log('🧹 Clearing old data...');
  await prisma.notification.deleteMany({});
  await prisma.tradeProposal.deleteMany({});
  await prisma.pointHistory.deleteMany({});
  await prisma.purchase.deleteMany({});
  await prisma.saleListing.deleteMany({});
  await prisma.photoCard.deleteMany({});
  await prisma.cardTemplate.deleteMany({});
  await prisma.point.deleteMany({});
  await prisma.user.deleteMany({});

  // =====================
  // 1. Users 및 Points 생성
  // =====================
  console.log('👤 Creating users and points...');
  const userIdMap = new Map(); // 가상 ID(1~20) -> DB UUID 매핑

  for (const u of RAW_USERS) {
    const hashedPassword = await bcrypt.hash(u.password, 10);
    const user = await prisma.user.create({
      data: {
        email: u.email,
        password: hashedPassword,
        nickname: u.nickname,
        point: {
          create: {
            balance: u.points,
          },
        },
      },
    });
    userIdMap.set(u.id, user.id);
  }

  // =====================
  // 2. CardTemplates 생성
  // =====================
  console.log('🃏 Creating card templates...');
  const templateIdMap = new Map(); // 가상 ID(1~100) -> DB AutoIncrement ID 매핑

  for (const t of RAW_TEMPLATES) {
    const creatorUuid = userIdMap.get(t.userId);
    if (!creatorUuid) continue;

    const template = await prisma.cardTemplate.create({
      data: {
        creatorId: creatorUuid,
        title: t.name,
        description: t.description,
        imageUrl: t.imageUrl,
        grade: gradeMap[t.grade] || 'COMMON',
        genre: genreMap[t.genre] || 'OTHER',
        price: t.price,
        totalIssued: t.totalQuantity,
      },
    });
    templateIdMap.set(t.id, template.id);
  }

  // =====================
  // 3. PhotoCards 생성 (소유권 관계)
  // =====================
  console.log('📸 Creating photo cards...');
  const photoCardMap = new Map(); // "templateId-userId" -> DB PhotoCard ID 매핑

  const photoCardOwnerMap = [
    { templateId: 1, userIds: [2, 1, 3], status: 'ON_SALE' },
    { templateId: 3, userIds: [14, 5, 6], status: 'OWNED' },
    { templateId: 4, userIds: [4, 6], status: 'ON_SALE' },
    { templateId: 5, userIds: [20, 9], status: 'ON_SALE' },
    { templateId: 6, userIds: [7, 18], status: 'ON_SALE' },
    { templateId: 10, userIds: [14, 8], status: 'ON_SALE' },
    { templateId: 12, userIds: [2, 8], status: 'OWNED' },
    { templateId: 14, userIds: [3, 16], status: 'ON_SALE' },
    { templateId: 15, userIds: [9, 11], status: 'ON_SALE' },
    { templateId: 16, userIds: [3, 5], status: 'ON_SALE' },
    { templateId: 19, userIds: [5, 16], status: 'ON_SALE' },
    { templateId: 20, userIds: [10, 1], status: 'IN_TRADE' },
    { templateId: 21, userIds: [3, 14], status: 'ON_SALE' },
    { templateId: 25, userIds: [3, 10], status: 'OWNED' },
    { templateId: 26, userIds: [11, 19], status: 'ON_SALE' },
    { templateId: 27, userIds: [14, 4], status: 'OWNED' },
    { templateId: 29, userIds: [2, 13], status: 'OWNED' },
    { templateId: 30, userIds: [18, 12], status: 'ON_SALE' },
  ];

  for (const pc of photoCardOwnerMap) {
    const dbTemplateId = templateIdMap.get(pc.templateId);
    if (!dbTemplateId) continue;

    for (const virtualUserId of pc.userIds) {
      const dbUserUuid = userIdMap.get(virtualUserId);
      if (!dbUserUuid) continue;

      const card = await prisma.photoCard.create({
        data: {
          templateId: dbTemplateId,
          ownerId: dbUserUuid,
          quantity: 1,
          status: pc.status,
        },
      });
      photoCardMap.set(`${pc.templateId}-${virtualUserId}`, card.id);
    }
  }

  // =====================
  // 4. SaleListings 생성
  // =====================
  console.log('🏪 Creating sale listings...');
  const saleListingIds = [];

  const saleListingData = [
    {
      templateId: 1,
      sellerId: 2,
      price: 8000,
      exGrade: 'RARE',
      exGenre: 'ALBUM',
      exDesc: 'RARE 등급 앨범 포카로 교환 원해요',
    },
    {
      templateId: 5,
      sellerId: 20,
      price: 26000,
      exGrade: 'SUPER_RARE',
      exGenre: 'FAN_SIGN',
      exDesc: 'SR 팬싸 포카로 교환 희망합니다',
    },
    {
      templateId: 6,
      sellerId: 7,
      price: 27000,
      exGrade: null,
      exGenre: null,
      exDesc: null,
    },
    {
      templateId: 10,
      sellerId: 14,
      price: 21000,
      exGrade: 'LEGENDARY',
      exGenre: 'CONCERT',
      exDesc: '레전더리 콘서트 포카로 교환해요',
    },
    {
      templateId: 14,
      sellerId: 3,
      price: 9000,
      exGrade: 'RARE',
      exGenre: 'ALBUM',
      exDesc: 'RARE 앨범 포카 교환 원합니다',
    },
    {
      templateId: 15,
      sellerId: 9,
      price: 21000,
      exGrade: null,
      exGenre: null,
      exDesc: null,
    },
    {
      templateId: 16,
      sellerId: 3,
      price: 28000,
      exGrade: 'SUPER_RARE',
      exGenre: 'FAN_SIGN',
      exDesc: 'SR 팬싸 교환 원해요',
    },
    {
      templateId: 19,
      sellerId: 5,
      price: 19000,
      exGrade: 'LEGENDARY',
      exGenre: 'FAN_SIGN',
      exDesc: '레전더리 팬싸 포카면 교환해요',
    },
    {
      templateId: 21,
      sellerId: 3,
      price: 24000,
      exGrade: null,
      exGenre: null,
      exDesc: null,
    },
    {
      templateId: 26,
      sellerId: 11,
      price: 20000,
      exGrade: 'RARE',
      exGenre: 'SPECIAL',
      exDesc: 'RARE 특전 교환 희망',
    },
    {
      templateId: 30,
      sellerId: 18,
      price: 15000,
      exGrade: 'SUPER_RARE',
      exGenre: 'ALBUM',
      exDesc: 'SR 앨범 포카로 교환해요',
    },
    {
      templateId: 4,
      sellerId: 4,
      price: 10000,
      exGrade: null,
      exGenre: null,
      exDesc: null,
    },
  ];

  for (const sl of saleListingData) {
    const dbSellerUuid = userIdMap.get(sl.sellerId);
    const dbPhotoCardId = photoCardMap.get(`${sl.templateId}-${sl.sellerId}`);

    if (!dbSellerUuid || !dbPhotoCardId) continue;

    const listing = await prisma.saleListing.create({
      data: {
        sellerId: dbSellerUuid,
        photoCardId: dbPhotoCardId,
        quantity: 1, // 필수 필드 충족
        remainQuantity: 1, // 필수 필드 충족
        price: sl.price,
        status: 'SELLING',
        exchangeGrade: sl.exGrade,
        exchangeGenre: sl.exGenre,
        exchangeDescription: sl.exDesc,
      },
    });
    saleListingIds.push(listing.id);
  }

  // =====================
  // 5. TradeProposals 생성 및 알림 처리
  // =====================
  console.log('🔄 Creating trade proposals...');

  const tradeProposalData = [
    {
      listingIdx: 0,
      proposerId: 5,
      offeredTemplateId: 3,
      offeredOwnerId: 5,
      message: '교환 원해요!',
    },
    {
      listingIdx: 0,
      proposerId: 6,
      offeredTemplateId: 4,
      offeredOwnerId: 6,
      message: '교환 조심스레 신청합니다.',
    },
    {
      listingIdx: 1,
      proposerId: 9,
      offeredTemplateId: 15,
      offeredOwnerId: 9,
      message: '교환 희망합니다',
    },
    {
      listingIdx: 4,
      proposerId: 16,
      offeredTemplateId: 19,
      offeredOwnerId: 16,
      message: '교환해요~',
    },
  ];

  for (let i = 0; i < tradeProposalData.length; i++) {
    const tp = tradeProposalData[i];
    const saleListingId = saleListingIds[tp.listingIdx];
    const dbProposerUuid = userIdMap.get(tp.proposerId);
    const dbOfferedCardId = photoCardMap.get(
      `${tp.offeredTemplateId}-${tp.offeredOwnerId}`
    );

    const originalListing = saleListingData[tp.listingIdx];
    const dbSellerUuid = userIdMap.get(originalListing.sellerId);

    if (!saleListingId || !dbProposerUuid || !dbOfferedCardId || !dbSellerUuid)
      continue;

    const status =
      i % 3 === 0 ? 'PENDING' : i % 3 === 1 ? 'ACCEPTED' : 'REJECTED';

    await prisma.tradeProposal.create({
      data: {
        saleListingId,
        proposerId: dbProposerUuid,
        offeredCardId: dbOfferedCardId,
        quantity: 1,
        status: status,
        message: tp.message,
        completedAt: status === 'ACCEPTED' ? new Date() : null,
      },
    });

    // 알림 생성
    await prisma.notification.create({
      data: {
        userId: dbSellerUuid,
        type: 'PROPOSAL_RECEIVED',
        message: '새로운 교환 제안이 도착했습니다.',
      },
    });

    if (status === 'ACCEPTED') {
      await prisma.notification.create({
        data: {
          userId: dbProposerUuid,
          type: 'PROPOSAL_ACCEPTED',
          message: '교환 제안이 수락되었습니다.',
        },
      });
    } else if (status === 'REJECTED') {
      await prisma.notification.create({
        data: {
          userId: dbProposerUuid,
          type: 'PROPOSAL_REJECTED',
          message: '교환 제안이 거절되었습니다.',
        },
      });
    }
  }

  // =====================
  // 6. Purchases 및 포인트 결제 로깅
  // =====================
  console.log('🛒 Creating purchases and handling point deductions...');

  const purchaseData = [
    { buyerId: 1, sellerId: 2, templateId: 1, listingIdx: 0, price: 8000 },
    { buyerId: 6, sellerId: 4, templateId: 4, listingIdx: 11, price: 10000 },
    { buyerId: 3, sellerId: 2, templateId: 1, listingIdx: 0, price: 8000 },
  ];

  for (const p of purchaseData) {
    const dbBuyerUuid = userIdMap.get(p.buyerId);
    const dbSellerUuid = userIdMap.get(p.sellerId);
    const dbPhotoCardId = photoCardMap.get(`${p.templateId}-${p.sellerId}`);
    const saleListingId = saleListingIds[p.listingIdx];

    if (!dbBuyerUuid || !dbSellerUuid || !dbPhotoCardId || !saleListingId)
      continue;

    const purchase = await prisma.purchase.create({
      data: {
        buyerId: dbBuyerUuid,
        sellerId: dbSellerUuid,
        photoCardId: dbPhotoCardId,
        saleListingId,
        quantity: 1, // 필수 필드 충족
        price: p.price,
      },
    });

    await prisma.pointHistory.createMany({
      data: [
        {
          userId: dbBuyerUuid,
          purchaseId: purchase.id,
          amount: -p.price,
          type: 'PURCHASE',
        },
        {
          userId: dbSellerUuid,
          purchaseId: purchase.id,
          amount: p.price,
          type: 'SALE',
        },
      ],
    });

    await prisma.point.update({
      where: { userId: dbBuyerUuid },
      data: { balance: { decrement: p.price } },
    });

    await prisma.point.update({
      where: { userId: dbSellerUuid },
      data: { balance: { increment: p.price } },
    });

    await prisma.saleListing.update({
      where: { id: saleListingId },
      data: { remainQuantity: { decrement: 1 } },
    });

    await prisma.notification.createMany({
      data: [
        {
          userId: dbBuyerUuid,
          type: 'PURCHASE_COMPLETED',
          message: '포토카드 구매가 완료되었습니다.',
        },
        {
          userId: dbSellerUuid,
          type: 'SOLD',
          message: '등록하신 포토카드가 판매되었습니다.',
        },
      ],
    });
  }

  console.log('✅ Seeding completed successfully!');
}

main()
  .catch((e) => {
    console.error('❌ Seeding failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
